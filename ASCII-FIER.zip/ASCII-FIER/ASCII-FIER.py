import os
from PIL import Image

# Open image file *MAKE SURE THE FILE PATH USES '/' AND NOT '\'*
filename = "image.png"
filepath = "C:/Users/[username]/Downloads/ASCII-FIER/image.png"

with Image.open(filepath) as image:
    # Convert image to grayscale
    image = image.convert("L")

    # Resize image
    width, height = image.size
    image = image.resize((int(width * 0.08), int(height * 0.08)))

    # Convert image to ASCII art
    ascii_art = ""
    for y in range(image.height):
        for x in range(image.width):
            pixel = image.getpixel((x, y))
            ascii_art += chr(ord('A') + pixel // 8)
        ascii_art += "\n"

    print(ascii_art)
